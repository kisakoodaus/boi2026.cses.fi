---
title: Instrukcijos
---

Visose užduotyse turite parašyti programą, kuri išsprendžia pateiktą problemą, ir pateikti programos kodą. **Kiekvienai užduočiai galite pateikti ne daugiau kaip 50 sprendimų.**

Pateiktas sprendimas bus vertinamas automatiškai. Po vertinimo galėsite matyti sprendimo gautą rezultatą su paaiškinimais (jei pateikiami).

Kiekvienas sprendimas vertinamas naudojant kelis testus. Kiekvienas testas gali turėti vieną iš šių rezultatų:

- ACCEPTED: jūsų programa pateikė teisingą atsakymą;
- WRONG ANSWER: jūsų programa pateikė neteisingą atsakymą;
- TIME LIMIT EXCEEDED: jūsų programa viršijo laiko limitą;
- RUNTIME ERROR: vykdant programą įvyko klaida arba ji sunaudojo per daug atminties;
- OUTPUT LIMIT EXCEEDED: jūsų programa išvedė per daug duomenų.

Testai yra suskirstyti į dalines užduotis, kurių kiekviena verta tam tikro taškų skaičiaus. Kiekvienai dalinei užduočiai pateikiamas vienas bendras rezultatas. Jei visų testų rezultatas yra ACCEPTED, tuomet ir dalinės užduoties rezultatas yra ACCEPTED. Kitu atveju dalinės užduoties rezultatas yra pirmojo testo, kuris nėra ACCEPTED, rezultatas.

Dalinė užduotis laikoma išspręsta, jei visi jos testai išspręsti teisingai ir neviršijant laiko bei atminties limitų. Jei užduoties aprašyme nenurodyta kitaip, sprendimas gauna taškus už visas dalines užduotis, kurias išsprendžia.

Galutinis dalinės užduoties balas yra didžiausias balas, gautas už tą dalinę užduotį tarp visų pateiktų sprendimų. Galutinis užduoties balas yra visų dalinių užduočių galutinių balų suma.

Jei norite kažko paklausti konkurso metu, galite siųsti žinutę CSES sistemoje.

# Interaktyvios užduotys

Interaktyviose užduotyse nepamirškite išvalyti (flush) išvesties buferio po kiekvieno spausdinimo.

C++: komanda `std::endl` išveda naujos eilutės simbolį ir išvalo išvesties buferį.

```cpp
std::cout << ... << std::endl;
```

Python: naudokite argumentą flush=True, kad užtikrintumėte išvesties buferio išvalymą.

```py
print(..., flush=True)
```