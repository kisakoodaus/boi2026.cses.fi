---
title: Instructions
---

In all tasks, you should write a program that solves the given problem, and submit the code of the program. **You can make at most 50 submissions per task.**

A submitted solution will be graded automatically. After the solution has been graded, you can view the score achieved by the submission and additional feedback if available.

Each submission will be graded on several test input. Each test input will have one of the following outcomes:

- ACCEPTED: your program produced the correct answer
- WRONG ANSWER: your program produced an incorrect answer
- TIME LIMIT EXCEEDED: your program used too much time
- RUNTIME ERROR: an error occurred in the execution of your program, or it used too much memory
- OUTPUT LIMIT EXCEEDED: your program printed too much

Test inputs are grouped into subtasks, each worth some points. You are shown a single outcome for each subtask. If the outcome of each test input is ACCEPTED, the outcome of the subtask is ACCEPTED. Otherwise the outcome of the subtask is the outcome of the first test input that is not ACCEPTED.

A subtask is considered solved if every test in it is solved correctly and within time and memory limits. Unless stated otherwise in the task description, a submission will receive points for all subtasks that it solves.

The final score for a subtask is the highest score received for that subtask over all submissions. The final score for a task is the sum of the final scores for its subtasks.

If you wish to ask something during the contest, you can send a message in CSES.

# Interactive tasks

In interactive tasks, remember to flush any output buffers after printing.

C++: The command `std::endl` prints a line separator and flushes the output buffer.

```cpp
std::cout << ... << std::endl;
```

Python: Pass the argument `flush=True` when printing to ensure the output is flushed.

```py
print(..., flush=True)
```
