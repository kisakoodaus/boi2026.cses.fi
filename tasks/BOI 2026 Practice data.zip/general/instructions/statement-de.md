---
title: Anweisungen
---

Bei allen Aufgaben sollst du ein Programm schreiben, das das gestellte Problem löst, und den Programmcode einsenden. **Du hast maximal 50 Einsendungen pro Aufgabe.**

Eine eingesendete Lösung wird automatisch bewertet. Nachdem die Lösung bewertet wurde, kannst du die erzielte Punktzahl sowie gegebenenfalls zusätzliches Feedback einsehen.

Jede Einsendung wird anhand mehrerer Tests bewertet. Jeder Test führt zu einem der folgenden Ergebnisse:

- ACCEPTED: Dein Programm hat die richtige Antwort geliefert
- WRONG ANSWER: Dein Programm hat eine falsche Antwort geliefert
- TIME LIMIT EXCEEDED: Dein Programm hat zu viel Zeit benötigt
- RUNTIME ERROR: Bei der Ausführung deines Programms ist ein Fehler aufgetreten oder es hat zu viel Speicher belegt
- OUTPUT LIMIT EXCEEDED: Dein Programm hat zu viel ausgegeben

Die Tests sind in Teilaufgaben gruppiert, die jeweils eine bestimmte Punktzahl wert sind. Für jede Teilaufgabe wird dir ein einziges Ergebnis angezeigt. Wenn das Ergebnis jedes Tests ACCEPTED lautet, ist das Ergebnis der Teilaufgabe ACCEPTED. Andernfalls ist das Ergebnis der Teilaufgabe das Ergebnis des ersten Tests, der nicht ACCEPTED ist.

Eine Teilaufgabe gilt als gelöst, wenn jeder darin enthaltene Test korrekt und innerhalb der Zeit- und Speichergrenzen gelöst wurde. Sofern in der Aufgabenbeschreibung nicht anders angegeben, erhält eine Einsendung Punkte für alle Teilaufgaben, die sie löst.

Die Endpunktzahl für eine Teilaufgabe ist die höchste Punktzahl, die für diese Teilaufgabe unter allen Einsendungen erzielt wurde. Die Endpunktzahl für eine Aufgabe ist die Summe der Endpunktzahlen ihrer Teilaufgaben.

Wenn du während des Wettbewerbs eine Frage hast, kannst du eine Nachricht in CSES senden.

# Interaktive Aufgaben

Denke bei interaktiven Aufgaben daran, die Ausgabebuffer nach der Ausgabe zu flushen.

C++: Der Befehl `std::endl` gibt ein Zeilentrennzeichen aus und flusht den Ausgabebuffer.

```cpp
std::cout << ... << std::endl;
```

Python: Übergebe beim Ausgeben das Argument `flush=True`, um sicherzustellen, dass die Ausgabe geflusht wird.

```py
print(..., flush=True)
```
