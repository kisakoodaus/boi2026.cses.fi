---
title: Instrukcija
---

Visos uzdevumos ir jāuzraksta programma, kas atrisina doto problēmu, un jāiesūta programmas kods. **Katrā uzdevumā var veikt ne vairāk kā 50 iesūtījumus.**

Iesūtītais risinājums tiks novērtēts automātiski. Pēc tam, kad risinājums būs novērtēts, varēsiet apskatīt iegūto punktu skaitu un papildu atsauksmes, ja tādas ir pieejamas.

Katrs iesūtījums tiks novērtēts pret vairākiem testu ievaddatiem. Katriem testa ievaddatiem būs viens no šādiem rezultātiem:

- ACCEPTED: jūsu programma izvadīja pareizo atbildi
- WRONG ANSWER: jūsu programma izvadīja nepareizu atbildi
- TIME LIMIT EXCEEDED: jūsu programma patērēja pārāk daudz laika
- RUNTIME ERROR: jūsu programmas izpildes laikā radās kļūda, vai arī tā izmantoja pārāk daudz atmiņas
- OUTPUT LIMIT EXCEEDED: jūsu programma izdrukāja pārāk daudz

Testi ir sagrupēti apakšuzdevumos, no kuriem katrs ir vērts noteiktu punktu skaitu. Jums tiek parādīts vienots rezultāts katram apakšuzdevumam. Ja katra testa rezultāts ir ACCEPTED, apakšuzdevuma rezultāts ir ACCEPTED. Pretējā gadījumā apakšuzdevuma rezultāts ir pirmā testa rezultāts, kas nav ACCEPTED.

Apakšuzdevums tiek uzskatīts par atrisinātu, ja tajā visi testi ir atrisināti pareizi laika un atmiņas ierobežojumu ietvaros. Ja uzdevuma aprakstā nav norādīts citādi, risinājums saņems punktus par visiem atrisinātajiem apakšuzdevumiem.

Gala vērtējums par apakšuzdevumu ir augstākais vērtējums, kas saņemts par šo apakšuzdevumu visos iesūtījumos. Gala vērtējums par uzdevumu ir tā apakšuzdevumu gala vērtējumu summa.

Ja vēlies kaut ko pajautāt sacensību laikā, vari sūtīt ziņu CSES.

# Interaktīvie uzdevumi

Interaktīvajos uzdevumos atceries pēc izdrukāšanas iztīrīt visu izvaddatu īslaicīgo atmiņu (izvades buferi).

C++: komanda `std::endl` izdrukā rindas atdalītāju un iztīra izvaddatus buferi.

```cpp
std::cout << ... << std::endl;
```

Python: padodiet argumentu `flush=True`, lai nodrošinātu, ka izvaddatu buferis tiek iztīrīts.

```py
print(..., flush=True)
```
