---
title: Instrukcje
---

W każdym zadaniu należy napisać program rozwiązujący podany problem i przesłać jego kod źródłowy. **W każdym zadaniu można wysłać co najwyżej 50 zgłoszeń.**

Przesłane rozwiązanie zostanie ocenione automatycznie. Po zakończeniu oceniania dostępny będzie uzyskany wynik oraz ewentualne dodatkowe informacje zwrotne.

Każde zgłoszenie jest oceniane na zbiorze testów. Dla każdego testu wynikiem może być:

- ACCEPTED: program wygenerował poprawną odpowiedź
- WRONG ANSWER: program wygenerował błędną odpowiedź
- TIME LIMIT EXCEEDED: program przekroczył limit czasu
- RUNTIME ERROR: wystąpił błąd wykonania programu lub przekroczono limit pamięci
- OUTPUT LIMIT EXCEEDED: program wygenerował zbyt duże wyjście

Testy są pogrupowane w podzadania, z których każde jest warte określoną liczbę punktów. Dla każdego podzadania wyświetlany jest pojedynczy wynik. Jeśli dla każdego testu w danym podzadaniu wynikiem jest ACCEPTED, to wynikiem podzadania jest ACCEPTED. W przeciwnym razie wynikiem podzadania jest wynik pierwszego testu, który nie został zaliczony (którego wynikiem nie jest ACCEPTED).

Podzadanie uznaje się za rozwiązane, jeśli wszystkie zawarte w nim testy zostały rozwiązane poprawnie, nie przekraczając limitów czasu i pamięci. O ile w treści zadania nie zaznaczono inaczej, zgłoszenie otrzymuje punkty za wszystkie rozwiązane podzadania.

Wynikiem końcowym dla danego podzadania jest najwyższy wynik uzyskany dla tego podzadania spośród wszystkich zgłoszeń. Wynikiem końcowym dla zadania jest suma wyników końcowych wszystkich jego podzadań.

Wszelkie pytania podczas zawodów należy przesyłać za pośrednictwem systemu CSES.

# Zadania interaktywne

W zadaniach interaktywnych należy pamiętać o opróżnianiu bufora wyjścia (flushowaniu) po każdym wypisaniu danych.

C++: Polecenie `std::endl` wypisuje znak końca linii i opróżnia bufor wyjścia.

```cpp
std::cout << ... << std::endl;
```

Python: Aby upewnić się, że bufor został opróżniony, należy wywołać funkcję `print` z argumentem `flush=True`.

```python
print(..., flush=True)
```