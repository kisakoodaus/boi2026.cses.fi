---
title: Juhend
---

Kõigi ülesannete puhul tuleb kirjutada programm, mis lahendab etteantud ülesande, ning esitada selle lähtekood. **Iga ülesande kohta võib esitada kuni 50 lahendust.**

Esitatud lahendust hinnatakse automaatselt. Pärast hindamist on võimalik näha lahenduse eest saadud punktisummat ning võimaluse korral ka lisatagasisidet.

Iga esitatud lahendust hinnatakse mitme testjuhu peal. Iga testjuhu puhul võib tulemus olla üks järgmistest:

- ACCEPTED: sinu programm andis õige vastuse
- WRONG ANSWER: sinu programm andis vale vastuse
- TIME LIMIT EXCEEDED: sinu programm ületas ajalimiidi
- RUNTIME ERROR: sinu programmi käivitamisel tekkis viga või see ületas mälupiirangu
- OUTPUT LIMIT EXCEEDED: sinu programm väljastas liiga palju andmeid

Testandmed on jaotatud gruppideks, millest igaühe eest antakse kindel arv punkte. Iga grupi kohta kuvatakse üks tulemus. Kui kõik selle grupi testid annavad tulemuseks ACCEPTED, siis on ka grupi tulemus ACCEPTED. Vastasel juhul määrab grupi tulemuse esimene test, mille tulemus ei ole ACCEPTED.

Grupp loetakse lahendatuks, kui kõik selle testid on lahendatud õigesti ning ajapiirangu ja mälupiirangu sees. Kui ülesande kirjelduses ei ole märgitud teisiti, saab esitatud lahendus punktid kõigi nende gruppide eest, mis on lahendatud.

Grupi lõpptulemuseks on selle grupi kõigi esituste hulgast saadud parim tulemus. Ülesande lõpptulemus on selle kõigi gruppide lõpptulemuste summa.

Kui soovid võistluse ajal midagi küsida, saad saata sõnumi CSES-is.

# Interaktiivsed ülesanded

Interaktiivsete ülesannete puhul tuleb pärast iga väljundi väljastamist tühjendada väljundpuhver.

C++: Käsk `std::endl` väljastab reavahetuse ja tühjendab väljundpuhvri.

```cpp
std::cout << ... << std::endl;
```

Python: anna funktsioonile `print` argumendiks `flush=True`, et väljundpuhver tühjendataks.

```py
print(..., flush=True)
```
