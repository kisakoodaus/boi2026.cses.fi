---
title: Command line submit usage
_note: THIS TEXT WILL NOT BE TRANSLATED
---

You can use the `cses` command to submit code from the command line. Usage:

```none
cses submit b.py              # Submit b.py to task B
cses submit mycode.cpp -t a   # Submit mycode.cpp to task A
cses samples -t c [directory] # Download samples for task C
```

Run `cses help` for more details.
