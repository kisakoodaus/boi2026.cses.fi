# BOI 2026 Practice (day0)

<https://boi2026.cses.fi>

## Structure

- general/
    - instructions/
    - documentation/
    - cmdline/
- day0/ (Practice)
    - boiancy/
    - eggs/
    - candies/

### Files

This is a custom format, NOT (quite) the Kattis format!

- `problem.yaml`: task manifest
- `statement-*.md`: statement and translations
- `files/*`: attachments needed for the statement
- `tests.txt`: test definitions (one per line)
- `samples.txt`: sample test definitions
- `generator.cpp`: input generator
- `checker.cpp`: input checker
- `solver.cpp`: output generator / model solution
- `grader.cpp`: custom grader, if applicable
- `solutions/*`: various test solutions. comment at beginning of file indicates expected outcomes
- `tests/*`: test files. proper tests as `1.in`, `1.out`, ..., samples as `samp-1.in`, `samp-1.out` (numbering overlaps)

### Rebuilding

Dependencies: GNU Make 4.4, GCC 14.3, Python 3.13

Tests can be regenerated and checked by running:

```
make tests
```

Run solver.cpp:

```
make run-tests
```
