#!/usr/bin/env bash
set -e
PREFIX=$2
mkdir -p tests
i=1
while IFS= read -r test
do
    id=$PREFIX$i
    if [[ $test = \#* ]]; then
        continue
    fi
    test=${test%\#*}

    manual=
    manual_changed=0
    if [[ $test = @* ]]; then
        manual="${test#@}"
        [[ $(echo $manual) -nt tests/$id.gen ]] && manual_changed=1
    fi

    echo "$test" > tests/$id.gen.tmp
    if ! cmp -s tests/$id.gen.tmp tests/$id.gen || [[ $manual_changed == 1 ]]; then
        cp tests/$id.gen.tmp tests/$id.gen
    fi
    rm tests/$id.gen.tmp
    echo $id
    ((i++))
done < "$1"
