#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>

using namespace std;

void fail(string comment = "") {
    cout << '0';
    erase(comment, '\n');
    if (comment != "") cout << ' ' << comment;
    cout << '\n';
    exit(0);
}

void accept() {
    cout << "1\n";
    exit(0);
}

struct Item {
    string content;
    int64_t l, c;
};

vector<Item> read(string name) {
    ifstream file;
    file.exceptions(ifstream::badbit);
    file.open(name);
    assert(file.is_open());
    vector<Item> data;
    string line, item;
    int l = 1;
    while (getline(file, line)) {
        istringstream buf(move(line));
        while (true) {
            buf >> ws;
            int c = buf.tellg();
            if (!(buf >> item)) break;
            data.push_back({move(item), l, c + 1});
        }
        l++;
    }
    return data;
}

string succinct(string item, int pos) {
    if (item.size() <= 15) return item;
    if (pos < 10) return item.substr(0, 12) + "...";
    if (pos + 3 >= (int)item.size()) return item.substr(0, 5) + "..." + item.substr(item.size() - 5);
    return item.substr(0, 5) + "..." + item.substr(pos - 2, 5) + "...";
}

int main(int argc, char **argv) {
    assert(argc >= 3);
    string input1 = argv[1];
    string input2 = argv[2];
    vector<Item> data1 = read(input1);
    vector<Item> data2 = read(input2);
    if (data2.size() < data1.size()) fail("Output is shorter than expected");
    if (data2.size() > data1.size()) fail("Output is longer than expected");
    for (size_t i = 0; i < data1.size(); i++) {
        auto& word1 = data1[i].content, word2 = data2[i].content;
        if (word1 != word2) {
            int pos = 0;
            while (pos < (int)min(word1.size(), word2.size()) && word1[pos] == word2[pos]) pos++;
            fail("Incorrect character on line " + to_string(data2[i].l) + " col " + to_string(data2[i].c + pos) +
                 ": expected \"" + succinct(word1, pos) + "\", got \"" + succinct(word2, pos) + "\"");
        }
    }
    accept();
}
