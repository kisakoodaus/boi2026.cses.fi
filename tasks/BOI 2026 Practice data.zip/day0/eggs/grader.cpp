#include <iostream>
#include <ostream>
#include <vector>

using namespace std;

void finish_graded_proc() {
    cerr << "kill" << endl;
}
void give_feedback(string s) {
    erase(s, '\n');
    erase(s, '\0');
    if (s != "") {
        if (s.size() > 500) s.resize(500);
        s.insert(0, "feedback ");
        s.push_back('\n');
        cerr << s << flush;
    }
}
void give_scores(vector<int> scores) {
    string s = "scores";
    for (int score : scores) {
        s.push_back(' ');
        s += to_string(score);
    }
    s.push_back('\n');
    cerr << s << flush;
}

// Give numerical grade to the user
[[noreturn]] void grade(int result, string feedback="") {
    give_feedback(std::move(feedback));
    exit(result);
}
// Indicate that program failed to produce the right answer
[[noreturn]] void fail(string feedback="") {
    give_feedback(std::move(feedback));
    finish_graded_proc();
    exit(0);
}
// Indicate that the user output was accepted
[[noreturn]] void accept(string feedback="") {
    give_feedback(std::move(feedback));
    exit(100);
}
#define SAFE_READ(x) \
    do               \
    {                \
        if (!(x))    \
            fail();  \
    } while (false)

int main(int argc, char **argv) {
    // TODO: get rid of this
    cerr << "encoder" << endl;

    int n, k, h, opt;
    cin >> n >> k >> h >> opt;

    cout << n << " " << k << endl;

    int query_count = 0;
    while (true) {
        char op;
        SAFE_READ(cin >> op);
        if (op == '?') {
            query_count++;
            if (query_count > opt) fail("Optimal number of drops " + to_string(opt) + " exceeded");
            int x;
            SAFE_READ(cin >> x);
            if (n <= 0) fail("No eggs left to drop");
            if (x < 1 || x > k) fail("x outside measuring stick");
            if (x <= h) {
                cout << "Intact" << endl;
            } else {
                cout << "Broken" << endl;
                n--;
            }
        } else if (op == '!') {
            int x;
            SAFE_READ(cin >> x);
            if (x == h) break;
            else fail("Wrong answer: expected " + to_string(h) + ", got " + to_string(x));
        } else fail("Unexpected operation");
    }

    accept(to_string(query_count) + " drops done");
}
