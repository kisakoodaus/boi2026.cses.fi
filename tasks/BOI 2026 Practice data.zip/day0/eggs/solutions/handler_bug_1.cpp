// WA

#include <iostream>
#include <map>
using namespace std;
typedef long long ll;

#define ans(x) {cout << "! " << x << endl; return 0;}

map<ll, ll> qm;
ll q(ll x){
    if (!qm.count(x)) {
        cout << "? " << x << endl;
        string s; cin >> s;
        qm[x] = (s == "Intact");
    }
    return qm[x];
}

signed main(){
    q(1);
    ans(1);
}
