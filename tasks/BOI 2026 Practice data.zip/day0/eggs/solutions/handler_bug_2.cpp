// WA/RE

#include <iostream>
#include <vector>
using namespace std;

int main(){
    cin.tie(0)->sync_with_stdio(0);
    int n,k;cin>>n>>k;

    vector<int> x(k*k*n+10000);

    int qcnt=0;
    auto ask=[&](int i) -> int {
        if(i>k)return 0;
        // if(x[i])return 0;
        qcnt++;
        cout<<"? "<<i<<'\n'<<flush;
        string s;cin>>s;
        return s=="Intact";
    };

    int a=2;
    while(ask(a))a++;
    cout<<"! "<<a-1<<'\n'<<flush;
}
