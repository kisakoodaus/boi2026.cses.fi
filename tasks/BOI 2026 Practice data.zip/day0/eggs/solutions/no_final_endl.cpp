// WA

// Should not TLE (gets stuck on last print)

#include <iostream>
using namespace std;
#define ll long long
#define MOD 1000000007

bool drop(int h) {
    cout << "? " << h << endl;
    string r;
    cin >> r;
    return r == "Intact";
}

int main() {
    int n, k;
    cin >> n >> k;
    int l = 1;
    int r = k;
    while (drop(l)) l++;
    cout << "! " << l-1;
}
