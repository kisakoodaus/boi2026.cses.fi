// Subtasks:
// 1: ACCEPTED
// _: WRONG ANSWER

#include <iostream>

using namespace std;

bool ask(int x) {
    cout << "? " << x << endl;
    string ans;
    cin >> ans;
    return ans == "Intact";
}

int main() {
    int n, k;
    cin >> n >> k;
    for (int x = 2; x <= k; ++x) {
        if (!ask(x)) {
            cout << "! " << x-1 << endl;
            return 0;
        }
    }
    cout << "! " << k << endl;
}
