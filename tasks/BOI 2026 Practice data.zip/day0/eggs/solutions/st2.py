# Subtasks:
# 1: AC
# 2: AC
# _: WA

n, k = map(int, input().split())

a, b = 1, k


def query(x):
    global a, b, n
    x = min(max(x, a), b)
    print("?", x, flush=True)
    res = input()
    if res == "Broken":
        b = x - 1
        n -= 1
    else:
        a = x


xs = 0
x = 0
while xs < b - a:
    x += 1
    xs += x

while a < b and n == 2:
    query(a + x)
    x -= 1

while a < b:
    query(a + 1)

print("!", a)
