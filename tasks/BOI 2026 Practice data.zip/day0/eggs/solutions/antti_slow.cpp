// Subtasks:
// 1: RE
// 2: RE
// 3: AC
// 4: AC
// 5: AC/TLE
// 6: RE/TLE

#include <iostream>

using namespace std;

bool dr[21][501][501];
pair<int,int> dp[21][501][501];

pair<int, int> find_best(int n, int a, int b) {
    if (a == b) return {0, a};
    if (n == 0) return {1e9, 0};
    if (dr[n][a][b]) return dp[n][a][b];
    pair<int,int> best = {1e9, 0};
    for (int i = a+1; i <= b; i++) {
        int r = max(find_best(n, i, b).first, find_best(n-1, a, i-1).first) + 1;
        best = min(best, {r, i});
    }
    dr[n][a][b] = true;
    dp[n][a][b] = best;
    return best;
}

void search(int n, int a, int b) {
    if (a == b) {
        cout << "! " << a << "\n";
        exit(0);
    }
    auto k = find_best(n, a, b).second;
    cout << "? " << k << "\n";
    string v;
    cin >> v;
    if (v == "Intact") search(n, k, b);
    else search(n-1, a, k-1);
}

void searchb(int a, int b) {
    if (a == b) {
        cout << "! " << a << "\n";
        exit(0);
    }
    int k = (a+b+1)/2;
    cout << "? " << k << "\n";
    string v;
    cin >> v;
    if (v == "Intact") searchb(k, b);
    else searchb(a, k-1);
}

int main() {
    int n, k;
    cin >> n >> k;
    if (n == 20) searchb(1, k);
    else search(n, 1, k);
}
