#include <cassert>
#include <iostream>
#include <vector>

using namespace std;

[[noreturn]] void usage() {
    cerr << "Usage: ./generator n k h" << endl;
    exit(1);
}

vector<vector<int>> do_dp(int n, int k) {
    vector<vector<int>> dp(n+1, vector<int>(k+1));
    for (int j = 1; j <= k; ++j) dp[1][j] = j-1;
    for (int i = 2; i <= n; ++i) {
        int x = 1;
        for (int j = 2; j <= k; ++j) {
            while (x < j && dp[i-1][x] < dp[i][j - x]) x++;
            dp[i][j] = 1 + max(dp[i-1][x], dp[i][j - x]);
        }
    }
    return dp;
}

int main(int argc, char **argv) {
    if (argc != 4) usage();
    int n = stoi(argv[1]);
    int k = stoi(argv[2]);
    int h = stoi(argv[3]);

    int optimal = do_dp(n, k)[n][k];

    cout << n << " " << k << " " << h << " " << optimal << endl;
}
