#include "cseslib.hpp"
#include <vector>

int main() {
    auto v = read_ints(4, 0, 1e5);
    int n = v[0];
    int k_ = v[1];
    int h = v[2];
    int opt = v[3];

    if (n < 1 || n > 20) fail();
    if (k_ < 1 || k_ > 1e5) fail();
    if (h < 1 || h > k_) fail();

    vector<int> g;
    if (n == 1) g.push_back(1);
    if (n == 2) g.push_back(2);
    if (n == 20) g.push_back(3);
    if (k_ <= 50) g.push_back(4);
    if (k_ <= 500) g.push_back(5);
    g.push_back(6);

    end_groups(g);
}
