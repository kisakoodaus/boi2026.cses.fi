#include <iostream>
#include <vector>
#include <algorithm>
#include <random>

using namespace std;

[[noreturn]] void usage()
{
    cerr << "Usage: ./generator seed number" << endl;
    exit(1);
}

mt19937 r_dev;
mt19937_64 r_dev64;
// Returns a value in range [0, 1[
double rnd()
{
    return uniform_real_distribution<double>(0, 1)(r_dev);
}
// Returns a value in range [a, b] inclusive
int rnd(int a, int b)
{
    return uniform_int_distribution<int>(a, b)(r_dev);
}
long long rnd64(long long a, long long b)
{
    return uniform_int_distribution<long long>(a, b)(r_dev64);
}
// Returns either 0 or 1
int coin()
{
    return rnd(0, 1);
}
// Shuffles any type with begin and end
template <typename T>
void shuffle(T &arr)
{
    shuffle(arr.begin(), arr.end(), r_dev);
}

int main(int argc, char **argv)
{
    // Parse arguments into numbers
    unsigned long long seed = stoull(argv[1]);
    r_dev.seed(seed);
    r_dev64.seed(seed);
    string type(argv[2]);
    if (type == "fixed") {
        string s(argv[3]);
        cout<<s.length()<<endl;
        cout<<s<<endl;
    } else if (type == "random") {
        int n = stoull(argv[3]);
        cout<<n<<endl;
        for (int i = 4; i < argc; i += 2) {
            int l = stoull(argv[i]);
            string x(argv[i + 1]);
            string alph;
            for (char c : x) {
                if (c == '*') alph += "ACDEFGHJKLMNPQRSTUVWXYZ"; // no BOI
                else alph += c;
            }
            for (int j = 0; j < l; j++) {
                cout<<alph[rnd(0, (int)alph.length() - 1)];
            }
        }
        cout<<endl;
    } else {
        cerr<<"Incorrect type "<<type<<endl;
        exit(1);
    }
}
