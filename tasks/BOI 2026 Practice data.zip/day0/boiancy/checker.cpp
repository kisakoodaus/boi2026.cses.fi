#include "cseslib.hpp"
#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
#include <string>

int main()
{
    int n = read_int(1, 1e6);
    string s = read_str(n, n, _AZ);
    
    vector<int> g;
    if (n <= 100) g.push_back(1);
    if (static_cast<int>(count(s.begin(), s.end(), 'O')) == 1) g.push_back(2);
    if (n <= 1000000) g.push_back(3);

    end_groups(g);
}
