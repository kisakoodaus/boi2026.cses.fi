#include <iostream>
#include <string>

using namespace std;

int main() {
	int n;
	cin>>n;
	string t;
	cin>>t;
	long long mod = 1000000007;
	long long b = 0;
	long long bo = 0;
	long long boi = 0;
	for (int i = 0; i < n; i++) {
		if (t[i] == 'B') b++;
		if (t[i] == 'O') bo += b;
		if (t[i] == 'I') boi += bo;
		b %= mod;
		bo %= mod;
		boi %= mod;
	}
	cout<<boi<<endl;
}
