#include <iostream>

using namespace std;

int main() {
	int n;
	cin>>n;
	long long a[n];
	long long total = 0;
	for (int i = 0; i < n; i++) {
		cin>>a[i];
		total += a[i];
	}
	if (total % 2 != 0) {
		cout<<"IMPOSSIBLE"<<endl;
		return 0;
	}
	long long sum = 0;
	for (int i = 0; i < n / 2; i++) {
		sum += a[i];
	}
	long long v = 0;
	for (int i = n / 2; i < n; i++) {
		long long opp = total - sum;
		v += llabs(sum - opp) / 2;
		sum += a[i];
		sum -= a[i - n / 2];
	}
	cout<<v<<endl;
}