#include "cseslib.hpp"
#include <iostream>
#include <vector>
#include <algorithm>
#include <set>

int main()
{
    int n = read_int(1, 1e5);
    if (n % 2 == 1) fail();
    vector<long long> v = read_ints(n, 0, 1e9);
    long long sum = 0;
    for (int i = 0; i < n; i++) sum += v[i];

    vector<int> g;
    if (n <= 4 && sum <= 4) g.push_back(1);
    if (v[0] == sum) g.push_back(2);
    g.push_back(3);

    end_groups(g);
}
