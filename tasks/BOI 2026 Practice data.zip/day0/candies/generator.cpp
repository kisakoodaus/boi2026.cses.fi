#include <iostream>
#include <vector>
#include <algorithm>
#include <random>

using namespace std;

[[noreturn]] void usage()
{
    cerr << "Usage: ./generator seed number" << endl;
    exit(1);
}

mt19937 r_dev;
mt19937_64 r_dev64;
// Returns a value in range [0, 1[
double rnd()
{
    return uniform_real_distribution<double>(0, 1)(r_dev);
}
// Returns a value in range [a, b] inclusive
int rnd(int a, int b)
{
    return uniform_int_distribution<int>(a, b)(r_dev);
}
long long rnd64(long long a, long long b)
{
    return uniform_int_distribution<long long>(a, b)(r_dev64);
}
// Returns either 0 or 1
int coin()
{
    return rnd(0, 1);
}
// Shuffles any type with begin and end
template <typename T>
void shuffle(T &arr)
{
    shuffle(arr.begin(), arr.end(), r_dev);
}

int main(int argc, char **argv)
{
    if (string(argv[1]) == "fixed") {
        cout<<(argc - 2)<<endl;
        for (int i = 2; i < argc; i++) {
            if (i != 2) cout<<" ";
            cout<<argv[i];
        }
    } else if (string(argv[1]) == "random") {
        unsigned long long seed = stoull(argv[2]);
        r_dev.seed(seed);
        r_dev64.seed(seed);
        int n = stoull(argv[3]);
        cout<<n<<endl;
        for (int i = 0; i < n; i++) {
            if (i) cout<<" ";
            cout<<rnd(0, 1000000000);
        }
    } else if (string(argv[1]) == "special") {
        unsigned long long seed = stoull(argv[2]);
        r_dev.seed(seed);
        r_dev64.seed(seed);
        int n = stoull(argv[3]);
        cout<<n<<endl;
        cout<<rnd(0, 1000000000);
        for (int i = 1; i < n; i++) {
            cout<<" 0";
        }
    } else if (string(argv[1]) == "small") {
        unsigned long long seed = stoull(argv[2]);
        r_dev.seed(seed);
        r_dev64.seed(seed);
        int n = stoull(argv[3]);
        cout<<n<<endl;
        int c[] = {0, 0, 0, 0};
        int x = stoull(argv[4]);
        for (int i = 0; i < x; i++) c[rnd(0, n - 1)]++;
        cout<<c[0];
        for (int i = 1; i < n; i++) {
            cout<<" "<<c[i];
        }
    } else {
        cerr<<"Unknown type "<<argv[1]<<endl;
        return 1;
    }
    cout<<endl;
}
